jqKeychange
===========

Key change jQuery plugin

Features
========

* trigger a jquery 'keyChange' event : it is an event which is between keypress and change event on an input or textarea.

Live demo here : http://jqkeychange.arnapou.net/
